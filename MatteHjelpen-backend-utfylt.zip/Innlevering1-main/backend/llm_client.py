"""LLM-klient for MatteHjelpen.

Orkestrerer samtalen mellom modellen og de deterministiske SymPy-verktøyene
i tools.py. Modellen resonnerer og velger verktøy; den regner ALDRI selv -
se docstring i tools.py og SYSTEMBESKRIVELSE.md.

Konfigurasjonsvalg (jf. PROMPTS/03_llm_client.md "FYLL INN SELV"):
- Maks antall tool-calling-runder: 8. Begrunnelse: en typisk oppgave
  trenger 1-3 verktøykall (f.eks. derivere, så validere et delsvar), så 8
  gir god margin uten å risikere en lang/uendelig løkke som spiser tokens.
- Hvis leverandøren ikke gir token-forbruk (usage=None, f.eks. enkelte
  gratis-endepunkt eller nettleser-limte svar): vi viser "ukjent" i stedet
  for å late som forbruket er 0 - ærlighetsprinsippet fra validator.py
  gjelder også her.
- Ekstra tillegg til systemprompten utover minimumskravet: vi ber modellen
  unngå unødvendig fagsjargong og alltid forklare HVORFOR et steg gjøres,
  ikke bare hva som gjøres - det er lettere for gruppen å kontrollere en
  forklaring de faktisk forstår.
"""

from __future__ import annotations

import json
import os

from dotenv import load_dotenv
from openai import OpenAI

from backend import tools as tools_modul
from backend.formelsamling import FORMELSAMLING

load_dotenv()

API_KEY = os.getenv("API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "deepseek/deepseek-chat-v3.1:free")
API_BASE_URL = os.getenv("API_BASE_URL", "https://openrouter.ai/api/v1")

USE_TOOLS = True  # <-- Aha-bryter nr. 1 (se OPPGAVE.md). Sett False og
# kjør de samme 10 oppgavene på nytt til EKSPERIMENT.md.

MAKS_TOOL_RUNDER = 8

# Grovt kostnadsestimat i USD per 1000 tokens (inn+ut regnet likt her, som
# er unøyaktig men greit nok til et estimat). 0 kr for gratis-modeller -
# sett denne til leverandørens faktiske pris når dere tester en betalt
# modell i Del B.
PRIS_PER_1K_TOKENS_USD = float(os.getenv("PRIS_PER_1K_TOKENS_USD", "0"))

SYSTEMPROMPT_KJERNE = (
    "Du er en matematikklærer for ingeniørstudenter. Bruk verktøyene (SymPy) "
    "til all beregning når oppgaven lar seg beregne slik - du skal ALDRI late "
    "som du har brukt et verktøy du ikke faktisk kalte. Kan oppgaven ikke "
    "beregnes (f.eks. et bevis eller en begrepsforklaring), resonnerer du i "
    "tekst og sier eksplisitt at svaret IKKE er verifisert av et verktøy. "
    "Forklar hvert steg pedagogisk på norsk, og oppgi nøyaktig hvilke "
    "formler/verktøy du faktisk brukte. Knytt hver formel-ID til steget der "
    "den brukes, og ta med navn og referanse fra formelsamlingen. "
    "Hvis du er usikker, si det eksplisitt."
)

SYSTEMPROMPT_TILLEGG = (
    "I tillegg: unngå unødvendig fagsjargong, og forklar alltid HVORFOR et "
    "steg gjøres (hvilket prinsipp/hvilken formel motiverer det), ikke bare "
    "HVA som gjøres. Skriv som om du forklarer for en medstudent."
)

SLUTTSVAR_INSTRUKS = """
Når du er ferdig og har all informasjonen du trenger (fra egne tool-kall,
hvis oppgaven kan beregnes), svar KUN med ett JSON-objekt - ingen tekst før
eller etter, ingen kodeblokk-merking - med nøyaktig disse feltene:

{
  "svar": "kortfattet sluttsvar, gjerne med LaTeX",
  "steg": ["forklaring av steg 1 ...", "forklaring av steg 2 ...", "..."],
  "formler_id": ["D1", "I1"]
}

Bruk kun formel-ID-er som faktisk finnes i formelsamlingen du fikk oppgitt
under. Ikke finn på egne ID-er.
"""


def _formelsamling_som_tekst() -> str:
    linjer = [
        f"{fid}: {f['navn']} - {f['formel']} (brukes: {f['bruk']}; ref: {f['referanse']})"
        for fid, f in FORMELSAMLING.items()
    ]
    return "\n".join(linjer)


def _bygg_systemprompt() -> str:
    return (
        SYSTEMPROMPT_KJERNE
        + "\n\n"
        + SYSTEMPROMPT_TILLEGG
        + "\n\nFormelsamling (ID: navn - formel (brukes: ...; ref: ...)):\n"
        + _formelsamling_som_tekst()
        + "\n"
        + SLUTTSVAR_INSTRUKS
    )


def _klient() -> OpenAI:
    if not API_KEY:
        raise RuntimeError(
            "API_KEY mangler. Kopier .env.example til .env og fyll inn en "
            "gratis API-nøkkel (se .env.example for alternativer)."
        )
    return OpenAI(api_key=API_KEY, base_url=API_BASE_URL)


def _kjor_tool(navn: str, argumenter: dict) -> dict:
    """Kjører ETT faktisk tool-kall og returnerer resultatet. Dette (ikke
    modellens egen fritekst-påstand) er kilden til verktøyloggen."""
    funksjon = getattr(tools_modul, navn, None)
    if funksjon is None or navn not in {t["function"]["name"] for t in tools_modul.TOOL_DEFINITIONS}:
        return {"feil": f"Ukjent verktøy: '{navn}'."}
    try:
        return funksjon(**argumenter)
    except TypeError as e:
        return {"feil": f"Feil argumenter til '{navn}': {e!r}"}
    except Exception as e:
        return {"feil": f"Verktøyet '{navn}' kastet en uventet feil: {e!r}"}


def _parse_sluttsvar(innhold: str) -> tuple[str, list[str], list[str]]:
    """Tolker modellens avsluttende JSON-svar. Faller ærlig tilbake til rå
    tekst hvis modellen ikke fulgte formatet, i stedet for å late som vi
    fikk strukturerte data vi ikke fikk."""
    renset = (innhold or "").strip()
    if renset.startswith("```"):
        renset = renset.strip("`")
        if "\n" in renset:
            forste_linje, resten = renset.split("\n", 1)
            renset = resten if forste_linje.strip().lower() in ("json", "") else renset

    try:
        data = json.loads(renset)
        svar = str(data.get("svar", "")).strip() or "(modellen oppga ikke noe 'svar'-felt)"
        steg = [str(s) for s in data.get("steg", [])]
        formel_ider = [str(fid) for fid in data.get("formler_id", [])]
        return svar, steg, formel_ider
    except (json.JSONDecodeError, AttributeError, TypeError):
        return (
            innhold or "(modellen ga ikke noe svar)",
            ["Modellen fulgte ikke det avtalte JSON-formatet - viser rå tekst som svar i stedet."],
            [],
        )


def solve_task(oppgave: str) -> dict:
    """Løser én matteoppgave via LLM + SymPy-verktøy.

    Returnerer en dict med: svar, steg, formler_brukt, verktoylogg,
    tokens_brukt, estimert_kostnad. Feltet "validert" settes IKKE her -
    det er validator.py sin jobb (kalt fra main.py), fordi validering
    skjer uavhengig av hva modellen selv påstår.
    """
    klient = _klient()

    meldinger = [
        {"role": "system", "content": _bygg_systemprompt()},
        {"role": "user", "content": oppgave},
    ]

    verktoylogg: list[dict] = []
    tokens_totalt = 0
    tokens_kjent = False
    siste_melding = None

    for _runde in range(MAKS_TOOL_RUNDER):
        respons = klient.chat.completions.create(
            model=MODEL_NAME,
            messages=meldinger,
            tools=tools_modul.TOOL_DEFINITIONS if USE_TOOLS else None,
            tool_choice="auto" if USE_TOOLS else None,
        )

        if getattr(respons, "usage", None) is not None:
            tokens_totalt += respons.usage.total_tokens
            tokens_kjent = True

        siste_melding = respons.choices[0].message
        tool_calls = getattr(siste_melding, "tool_calls", None)

        if not tool_calls:
            break

        meldinger.append(
            {
                "role": "assistant",
                "content": siste_melding.content or "",
                "tool_calls": [tc.model_dump() for tc in tool_calls],
            }
        )
        for tc in tool_calls:
            navn = tc.function.name
            try:
                argumenter = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                argumenter = {}
            resultat = _kjor_tool(navn, argumenter)
            verktoylogg.append({"verktoy": navn, "argumenter": argumenter, "resultat": resultat})
            meldinger.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(resultat, ensure_ascii=False),
                }
            )
    else:
        # Løkken nådde MAKS_TOOL_RUNDER uten at modellen ga et sluttsvar.
        verktoylogg.append(
            {
                "verktoy": None,
                "argumenter": None,
                "resultat": {"feil": f"Nådde grensen på {MAKS_TOOL_RUNDER} tool-runder uten sluttsvar."},
            }
        )

    innhold = (siste_melding.content if siste_melding else "") or ""
    svar, steg, foreslatte_formel_ider = _parse_sluttsvar(innhold)

    # Anti-hallusinasjon: aksepter kun formel-ID-er som faktisk finnes i
    # FORMELSAMLING. En gyldig ID viser hvor regelen står i pensum - den
    # beviser ikke at regelen ble brukt riktig eller at et tool-kall skjedde.
    formler_brukt = [
        {"id": fid, **FORMELSAMLING[fid]} for fid in foreslatte_formel_ider if fid in FORMELSAMLING
    ]

    return {
        "svar": svar,
        "steg": steg,
        "formler_brukt": formler_brukt,
        "verktoylogg": verktoylogg,
        "tokens_brukt": tokens_totalt if tokens_kjent else "ukjent",
        "estimert_kostnad": round(tokens_totalt / 1000 * PRIS_PER_1K_TOKENS_USD, 6) if tokens_kjent else "ukjent",
    }
