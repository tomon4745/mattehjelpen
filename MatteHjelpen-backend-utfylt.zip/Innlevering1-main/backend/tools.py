"""Deterministiske matteverktøy (SymPy) for MatteHjelpen.

PRINSIPP: Modellen resonnerer - verktøyet regner. En språkmodell skal ALDRI
gjøre symbolsk/numerisk regning selv; alle seks funksjonene under bruker
SymPy til selve utregningen og returnerer alltid {"resultat": str, "latex": str}.

Feilhåndtering (valget vi har tatt, jf. PROMPTS/01_tools.md "FYLL INN SELV"):
Vi returnerer feil som del av dictet, {"feil": "..."}, i stedet for å kaste
exceptions videre til modellen. Grunnen: en tool-calling-løkke skal kunne
sende feilmeldingen tilbake til modellen som et vanlig tool-resultat, slik at
modellen kan forklare feilen til brukeren i stedet for at hele forespørselen
krasjer. `llm_client.py` fanger i tillegg uventede exceptions rundt kallet.

Tolkning av tvetydig notasjon (det andre "FYLL INN SELV"-punktet): vi tolker
`sin^-1(x)` og lignende som EKSPONENT (potens), ikke som invers funksjon,
fordi det er slik `**`/`^` fungerer matematisk i en vanlig parser. Dette er
bevisst valgt som et av "aha-punktene" i OPPGAVE.md: hvis en bruker skriver
`sin^-1(x)` og mener arcsin, vil SymPy regne (sin(x))**-1 = 1/sin(x), altså
riktig regnet på FEIL tolket problem. Bruk heller `asin(x)` eller `arcsin(x)`
for den inverse funksjonen - dette er dokumentert her og i EKSPERIMENT.md.
"""

from __future__ import annotations

import sympy
from sympy.parsing.sympy_parser import (
    standard_transformations,
    implicit_multiplication_application,
    convert_xor,
    parse_expr,
)

_TRANSFORMATIONS = standard_transformations + (
    implicit_multiplication_application,
    convert_xor,
)

# Faste navn appen kjenner igjen i uttrykk, slik at "x", "y(x)", "I", "E" osv.
# ikke blir tolket som frie symboler ved en tilfeldighet.
_X = sympy.Symbol("x")
_Y = sympy.Function("y")
_BASISNAVN = {
    "x": _X,
    "y": _Y,
    "I": sympy.I,
    "E": sympy.E,
    "pi": sympy.pi,
    "oo": sympy.oo,
}


def _parse(uttrykk: str, ekstra_navn: dict | None = None):
    """Parser en matte-streng til et SymPy-uttrykk.

    Bruker implisitt multiplikasjon (så "2x" fungerer som "2*x") og "^" som
    potens. Se docstringen øverst i filen om hvordan sin^-1(x) tolkes.
    """
    navn = dict(_BASISNAVN)
    if ekstra_navn:
        navn.update(ekstra_navn)
    return parse_expr(uttrykk, local_dict=navn, transformations=_TRANSFORMATIONS, evaluate=True)


def _symbol(variabel: str) -> sympy.Symbol:
    return sympy.Symbol(variabel)


def _pakke(resultat_sympy) -> dict:
    return {"resultat": str(resultat_sympy), "latex": sympy.latex(resultat_sympy)}


def derive(uttrykk: str, variabel: str = "x") -> dict:
    """Deriverer et uttrykk med hensyn på en variabel, med sympy.diff."""
    try:
        var = _symbol(variabel)
        expr = _parse(uttrykk, {variabel: var})
        return _pakke(sympy.diff(expr, var))
    except Exception as e:
        return {"feil": f"Kunne ikke derivere '{uttrykk}' mhp. '{variabel}': {e!r}"}


def integrate(uttrykk: str, variabel: str = "x") -> dict:
    """Integrerer et uttrykk (ubestemt integral) med sympy.integrate."""
    try:
        var = _symbol(variabel)
        expr = _parse(uttrykk, {variabel: var})
        resultat = sympy.integrate(expr, var)
        pakket = _pakke(resultat)
        pakket["resultat"] = pakket["resultat"] + " + C"
        pakket["latex"] = pakket["latex"] + " + C"
        return pakket
    except Exception as e:
        return {"feil": f"Kunne ikke integrere '{uttrykk}' mhp. '{variabel}': {e!r}"}


def solve_equation(ligning: str, variabel: str = "x") -> dict:
    """Løser en ligning (eller et uttrykk, implisitt = 0) med sympy.solve.

    Godtar både "x**2 - 4" (implisitt = 0) og "x**2 = 4" (med likhetstegn).
    """
    try:
        var = _symbol(variabel)
        if "=" in ligning:
            venstre, hoyre = ligning.split("=", 1)
            expr = _parse(venstre, {variabel: var}) - _parse(hoyre, {variabel: var})
        else:
            expr = _parse(ligning, {variabel: var})
        losninger = sympy.solve(expr, var)
        return _pakke(losninger)
    except Exception as e:
        return {"feil": f"Kunne ikke løse '{ligning}' for '{variabel}': {e!r}"}


def solve_ode(ligning: str) -> dict:
    """Løser en differensialligning i y(x) med sympy.dsolve.

    Ligningen skrives med `y` og `x`, f.eks. "y(x).diff(x) + 4*y(x)"
    (implisitt = 0) eller "y(x).diff(x,2) + 4*y(x) = 0".
    """
    try:
        if "=" in ligning:
            venstre, hoyre = ligning.split("=", 1)
            expr = _parse(venstre) - _parse(hoyre)
        else:
            expr = _parse(ligning)
        ligning_eq = sympy.Eq(expr, 0)
        losning = sympy.dsolve(ligning_eq, _Y(_X))
        return _pakke(losning)
    except Exception as e:
        return {"feil": f"Kunne ikke løse differensialligningen '{ligning}': {e!r}"}


def matrix_op(operasjon: str, matrise: list) -> dict:
    """Matriseoperasjoner: determinant, invers, egenverdier, løs Ax=b.

    `matrise` er en liste av rader, f.eks. [[1, 2], [3, 4]]. For
    operasjon="los_ax_b" må hver rad ha b-verdien til slutt, dvs. matrisen
    er den utvidede matrisen [A|b], f.eks. [[1, 2, 5], [3, 4, 6]].
    """
    try:
        op = operasjon.strip().lower()
        M = sympy.Matrix(matrise)

        if op in ("determinant", "det"):
            return _pakke(M.det())
        if op in ("invers", "inverse", "invert"):
            return _pakke(M.inv())
        if op in ("egenverdier", "eigenvalues", "eigen"):
            return _pakke(M.eigenvals())
        if op in ("los_ax_b", "løs_ax_b", "solve", "los", "løs"):
            A = M[:, :-1]
            b = M[:, -1]
            losning = A.solve(b)
            return _pakke(losning)

        return {"feil": f"Ukjent matriseoperasjon: '{operasjon}'. Gyldige: determinant, invers, egenverdier, los_ax_b."}
    except Exception as e:
        return {"feil": f"Kunne ikke utføre matriseoperasjon '{operasjon}': {e!r}"}


def _parse_komplekst(tall: str) -> sympy.Expr:
    """Tolker en streng som et komplekst tall. Godtar både Python-stil
    ("1+1j") og matematikk-/SymPy-stil ("1+I")."""
    renset = tall.strip().replace(" ", "")
    try:
        pytall = complex(renset.replace("i", "j"))
        return sympy.nsimplify(pytall.real) + sympy.nsimplify(pytall.imag) * sympy.I
    except ValueError:
        pass
    return _parse(renset.replace("i", "I").replace("j", "I"))


def complex_op(operasjon: str, tall: str) -> dict:
    """Operasjoner på komplekse tall: polarform, Eulers/eksponentiell form,
    potenser og n-te røtter.

    `tall` er selve det komplekse tallet/uttrykket, f.eks. "1+1j" eller en
    SymPy-vennlig streng som "(1+I)**3" for en potens.

    `operasjon` styrer hva som returneres:
    - "polar"           -> r*(cos(theta) + i*sin(theta))
    - "euler"           -> r*e^(i*theta)
    - "rektangulaer"    -> forenklet a + b*i (standardvalg for ukjent operasjon)
    - "røtter:n"        -> liste med alle n n-te røtter av tallet (default n=2)
    """
    try:
        z = sympy.expand_complex(sympy.nsimplify(_parse_komplekst(tall)))
        op = operasjon.strip().lower()

        r = sympy.sqrt(sympy.re(z) ** 2 + sympy.im(z) ** 2)
        theta = sympy.atan2(sympy.im(z), sympy.re(z))

        if op.startswith("polar"):
            # Bygges som tekst i stedet for ett sympy-uttrykk, ellers
            # forenkler SymPy "pene" vinkler (f.eks. pi/4) rett tilbake til
            # rektangulær form og polarformen forsvinner fra svaret.
            r_s, theta_s = str(r), str(theta)
            return {
                "resultat": f"{r_s}*(cos({theta_s}) + i*sin({theta_s}))",
                "latex": sympy.latex(r) + r"\left(\cos(" + sympy.latex(theta) + r") + i\sin(" + sympy.latex(theta) + r")\right)",
            }
        if op.startswith("euler") or op.startswith("eksponen"):
            return {"resultat": f"{r}*e^(i*{theta})", "latex": sympy.latex(r) + r" \cdot e^{i\," + sympy.latex(theta) + "}"}
        if op.startswith("rot") or op.startswith("røtter"):
            n = 2
            if ":" in operasjon:
                try:
                    n = int(operasjon.split(":", 1)[1])
                except ValueError:
                    n = 2
            k = sympy.symbols("k")
            roetter = [
                sympy.simplify(r ** sympy.Rational(1, n) * sympy.exp(sympy.I * (theta + 2 * sympy.pi * i) / n))
                for i in range(n)
            ]
            return {
                "resultat": ", ".join(str(rt) for rt in roetter),
                "latex": ", ".join(sympy.latex(rt) for rt in roetter),
            }
        # "potens" og alt annet: uttrykket kan allerede inneholde potensen
        # (f.eks. tall="(1+I)**3") - vi forenkler bare til rektangulær form.
        return _pakke(z)
    except Exception as e:
        return {"feil": f"Kunne ikke utføre komplekstall-operasjon '{operasjon}' på '{tall}': {e!r}"}


TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "derive",
            "description": "Deriver et matematisk uttrykk med hensyn på en variabel (SymPy diff).",
            "parameters": {
                "type": "object",
                "properties": {
                    "uttrykk": {"type": "string", "description": "Uttrykket som skal deriveres, f.eks. 'x**2*sin(x)'."},
                    "variabel": {"type": "string", "description": "Variabelen det deriveres mhp., default 'x'."},
                },
                "required": ["uttrykk"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "integrate",
            "description": "Integrer et matematisk uttrykk (ubestemt integral) med hensyn på en variabel (SymPy integrate).",
            "parameters": {
                "type": "object",
                "properties": {
                    "uttrykk": {"type": "string", "description": "Uttrykket som skal integreres."},
                    "variabel": {"type": "string", "description": "Integrasjonsvariabel, default 'x'."},
                },
                "required": ["uttrykk"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "solve_equation",
            "description": "Løs en algebraisk ligning for en variabel (SymPy solve). Godtar 'uttrykk=0' eller 'venstre=høyre'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ligning": {"type": "string", "description": "Ligningen som skal løses, f.eks. 'x**2 - 4' eller 'x**2 = 4'."},
                    "variabel": {"type": "string", "description": "Variabelen som løses for, default 'x'."},
                },
                "required": ["ligning"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "solve_ode",
            "description": "Løs en differensialligning i y(x) (SymPy dsolve). Skriv med y(x).diff(x, n).",
            "parameters": {
                "type": "object",
                "properties": {
                    "ligning": {"type": "string", "description": "Differensialligningen, f.eks. 'y(x).diff(x) + 4*y(x)'."},
                },
                "required": ["ligning"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "matrix_op",
            "description": "Matriseoperasjoner: determinant, invers, egenverdier, eller løs Ax=b (utvidet matrise [A|b]).",
            "parameters": {
                "type": "object",
                "properties": {
                    "operasjon": {"type": "string", "enum": ["determinant", "invers", "egenverdier", "los_ax_b"]},
                    "matrise": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "number"}},
                        "description": "Liste av rader. For los_ax_b: siste kolonne er b.",
                    },
                },
                "required": ["operasjon", "matrise"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "complex_op",
            "description": "Operasjoner på komplekse tall: polar, euler, potens eller røtter:n (n-te røtter).",
            "parameters": {
                "type": "object",
                "properties": {
                    "operasjon": {"type": "string", "description": "'polar', 'euler', 'potens' eller 'røtter:n'."},
                    "tall": {"type": "string", "description": "Det komplekse tallet/uttrykket, f.eks. '1+1j' eller '(1+I)**3'."},
                },
                "required": ["operasjon", "tall"],
            },
        },
    },
]
