"""Innebygd formelsamling – à la Jarle Johannessen: «Tekniske Tabeller».

Modellen skal referere til formler herfra i sine forklaringer.
Utvid gjerne med formler fra Edwards & Penney og Thomas' Calculus.

Feltet «bruk» hjelper modellen å velge regel. Modellen oppgir formel-ID i
løsningssteget; appen kontrollerer ID-en og henter navn og referanse herfra.

HVORFOR: Sporbarhet. «Hvilken formel brukte du, og hvor står den?» er et
spørsmål enhver ingeniør må kunne svare på.
"""

FORMELSAMLING = {
    "D1": {
        "navn": "Produktregelen",
        "formel": r"(uv)' = u'v + uv'",
        "referanse": "Thomas' Calculus, kap. 3",
        "bruk": "Når et produkt av to funksjoner skal deriveres.",
    },
    "D2": {
        "navn": "Kjerneregelen",
        "formel": r"\frac{dy}{dx} = \frac{dy}{du}\cdot\frac{du}{dx}",
        "referanse": "Thomas' Calculus, kap. 3",
        "bruk": "Når en sammensatt funksjon skal deriveres.",
    },
    "I1": {
        "navn": "Delvis integrasjon",
        "formel": r"\int u\,dv = uv - \int v\,du",
        "referanse": "Thomas' Calculus, kap. 8",
        "bruk": "Når integralet inneholder et produkt som blir enklere etter derivasjon av én faktor.",
    },
    "O1": {
        "navn": "Karakteristisk ligning (2. ordens lineær ODE)",
        "formel": r"ar^2 + br + c = 0 \text{ for } ay'' + by' + cy = 0",
        "referanse": "Edwards & Penney, kap. 3",
        "bruk": "Når en homogen lineær differensialligning med konstante koeffisienter skal løses.",
    },
    "K1": {
        "navn": "Eulers formel",
        "formel": r"e^{i\theta} = \cos\theta + i\sin\theta",
        "referanse": "Buanes: Komplekse tall",
        "bruk": "Når komplekse tall skal kobles mellom eksponentialform og trigonometrisk form.",
    },
    "M1": {
        "navn": "Determinant (2x2)",
        "formel": r"\det\begin{pmatrix}a & b\\ c & d\end{pmatrix} = ad - bc",
        "referanse": "Edwards & Penney, kap. 4",
        "bruk": "Når determinanten til en 2x2-matrise skal beregnes eller inverterbarhet vurderes.",
    },
    "D3": {
        "navn": "Potensregelen",
        "formel": r"\frac{d}{dx}x^n = n\,x^{n-1}",
        "referanse": "Thomas' Calculus, kap. 3",
        "bruk": "Når en potens av variabelen skal deriveres.",
    },
    "D4": {
        "navn": "Kvotientregelen",
        "formel": r"\left(\frac{u}{v}\right)' = \frac{u'v - uv'}{v^2}",
        "referanse": "Thomas' Calculus, kap. 3",
        "bruk": "Når en brøk av to funksjoner skal deriveres.",
    },
    "D5": {
        "navn": "Derivert av trigonometriske funksjoner",
        "formel": r"\frac{d}{dx}\sin x = \cos x,\quad \frac{d}{dx}\cos x = -\sin x",
        "referanse": "Thomas' Calculus, kap. 3",
        "bruk": "Når sinus eller cosinus (evt. sammensatt med kjerneregelen) skal deriveres.",
    },
    "I2": {
        "navn": "Substitusjon (variabelskifte)",
        "formel": r"\int f(g(x))g'(x)\,dx = \int f(u)\,du,\ u=g(x)",
        "referanse": "Thomas' Calculus, kap. 5",
        "bruk": "Når integranden inneholder en sammensatt funksjon og dens deriverte.",
    },
    "I3": {
        "navn": "Potensregelen for integrasjon",
        "formel": r"\int x^n\,dx = \frac{x^{n+1}}{n+1} + C,\ n \neq -1",
        "referanse": "Thomas' Calculus, kap. 5",
        "bruk": "Når en potens av variabelen skal integreres.",
    },
    "O2": {
        "navn": "Generell løsning, homogen 2. ordens lineær ODE",
        "formel": r"y = C_1 e^{r_1 x} + C_2 e^{r_2 x}\ (r_1 \neq r_2 \text{ reelle})",
        "referanse": "Edwards & Penney, kap. 3",
        "bruk": "Når røttene til den karakteristiske ligningen (O1) er reelle og forskjellige.",
    },
    "O3": {
        "navn": "Integrerende faktor (1. ordens lineær ODE)",
        "formel": r"\mu(x) = e^{\int p(x)\,dx} \text{ for } y' + p(x)y = q(x)",
        "referanse": "Edwards & Penney, kap. 1",
        "bruk": "Når en førsteordens lineær differensialligning skal løses.",
    },
    "K2": {
        "navn": "De Moivres formel",
        "formel": r"(\cos\theta + i\sin\theta)^n = \cos(n\theta) + i\sin(n\theta)",
        "referanse": "Buanes: Komplekse tall",
        "bruk": "Når en potens av et komplekst tall på polarform skal beregnes.",
    },
    "K3": {
        "navn": "n-te røtter av et komplekst tall",
        "formel": r"z^{1/n} = r^{1/n}\left(\cos\frac{\theta+2k\pi}{n} + i\sin\frac{\theta+2k\pi}{n}\right),\ k=0,\dots,n-1",
        "referanse": "Buanes: Komplekse tall",
        "bruk": "Når alle n-te røtter av et komplekst tall skal finnes.",
    },
    "M2": {
        "navn": "Invers av 2x2-matrise",
        "formel": r"A^{-1} = \frac{1}{\det A}\begin{pmatrix}d & -b\\ -c & a\end{pmatrix}",
        "referanse": "Edwards & Penney, kap. 4",
        "bruk": "Når den inverse matrisen til en 2x2-matrise skal beregnes (krever det(A) ≠ 0).",
    },
    "M3": {
        "navn": "Egenverdier via karakteristisk polynom",
        "formel": r"\det(A - \lambda I) = 0",
        "referanse": "Edwards & Penney, kap. 4",
        "bruk": "Når egenverdiene til en kvadratisk matrise skal finnes.",
    },
    "M4": {
        "navn": "Løsning av lineært likningssystem Ax=b",
        "formel": r"x = A^{-1}b \text{ (hvis } A \text{ er inverterbar)}",
        "referanse": "Edwards & Penney, kap. 4",
        "bruk": "Når et lineært likningssystem skal løses med matriser.",
    },
}
