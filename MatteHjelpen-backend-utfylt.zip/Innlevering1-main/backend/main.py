"""MatteHjelpen - FastAPI-backend.

Kobler sammen llm_client.solve_task (LLM + SymPy-verktøy) og
validator.validate (uavhengig numerisk kontroll av svaret) til én
JSON-respons for frontend. Se SYSTEMBESKRIVELSE.md for kontrakten.

Feilhåndtering: vises ærlig til brukeren i "svar"-feltet i stedet for å gi
en rå 500-feil uten forklaring - både LLM-kall (nettverk, manglende
API-nøkkel, ugyldig modellnavn) og validering kan feile uavhengig av
hverandre.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from backend import llm_client, validator

app = FastAPI(title="MatteHjelpen")

# Åpent for lokal utvikling (frontend og backend kjører på samme origin her,
# men CORS holdes åpent i tilfelle dere kjører frontend separat under utvikling).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class Oppgave(BaseModel):
    oppgave: str


@app.get("/")
async def index():
    return FileResponse("frontend/index.html")


@app.post("/solve")
async def solve(oppgave: Oppgave):
    try:
        losning = llm_client.solve_task(oppgave.oppgave)
    except Exception as e:
        return {
            "svar": f"Fikk ikke løst oppgaven - feil under kall til språkmodellen: {e!r}. "
            "Sjekk at .env har gyldig API_KEY/MODEL_NAME/API_BASE_URL (se .env.example).",
            "steg": [],
            "formler_brukt": [],
            "validert": False,
            "valideringsdetaljer": "Ingen validering forsøkt - LLM-kallet feilet først.",
            "tokens_brukt": 0,
            "estimert_kostnad": 0.0,
        }

    try:
        validering = validator.validate(oppgave.oppgave, str(losning.get("svar", "")))
    except Exception as e:
        validering = {"validert": False, "detaljer": f"Validering feilet uventet: {e!r}"}

    return {
        "svar": losning.get("svar", ""),
        "steg": losning.get("steg", []),
        "formler_brukt": losning.get("formler_brukt", []),
        "verktoylogg": losning.get("verktoylogg", []),
        "validert": validering.get("validert", False),
        "valideringsdetaljer": validering.get("detaljer", ""),
        "tokens_brukt": losning.get("tokens_brukt", 0),
        "estimert_kostnad": losning.get("estimert_kostnad", 0.0),
    }
