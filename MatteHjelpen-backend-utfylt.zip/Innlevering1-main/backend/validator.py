"""Numerisk validering av løsninger.

HVORFOR: Etterprøvbarhet er ikke valgfritt for ingeniører. Hvis appen sier at
y(x) løser differensialligningen, skal vi SJEKKE det - ved å sette løsningen
inn i originalproblemet og evaluere numerisk i flere punkter.

Toleranse (jf. PROMPTS/04_validator.md "FYLL INN SELV"): vi bruker 1e-6.
Flyttallsregning med sqrt/trig-funksjoner gir avrundingsfeil i størrelses-
orden 1e-14 til 1e-10 normalt, så 1e-6 er romslig nok til å ikke gi falske
"feil"-utslag av avrunding alene, men strengt nok til å fange faktisk feil
regnede løsninger.

Hva vi IKKE klarer å validere automatisk (returnerer validert=False med
ærlig forklaring i "detaljer", i stedet for å late som alt er OK):
- Bevis- og begrepsoppgaver ("bevis Pythagoras' læresetning") - det finnes
  ingen numerisk sjekk for et bevis.
- Rene symbolske svar uten tallverdi å stikke inn (f.eks. "uendelig mange
  løsninger" eller ubestemte integraler der SymPy selv ikke finner en
  lukket form).
- Oppgaver der vi ikke klarer å tolke hverken problem- eller løsningsstrengen
  som et SymPy-uttrykk (parsing feiler).
"""

from __future__ import annotations

import random

import sympy
from sympy.parsing.sympy_parser import (
    standard_transformations,
    implicit_multiplication_application,
    convert_xor,
    parse_expr,
)

_TRANSFORMATIONS = standard_transformations + (
    implicit_multiplication_application,
    convert_xor,
)

_TOLERANSE = 1e-6
_X = sympy.Symbol("x")
_Y = sympy.Function("y")
_BASISNAVN = {"x": _X, "y": _Y, "I": sympy.I, "E": sympy.E, "pi": sympy.pi}


def _parse(uttrykk: str):
    return parse_expr(uttrykk, local_dict=_BASISNAVN, transformations=_TRANSFORMATIONS, evaluate=True)


def _er_ode(tekst: str) -> bool:
    # "y(x)" er den pålitelige markøren for at oppgaven handler om en
    # ukjent funksjon y (en ODE). Vi trigger bevisst IKKE bare på "diff(",
    # siden det også brukes til å sjekke rene deriverte-identiteter
    # (f.eks. "diff(x**2, x) = 2*x"), som skal gjennom den algebraiske
    # sjekken i stedet.
    return "y(x)" in tekst or "dsolve" in tekst


def validate(problem: str, losning: str) -> dict:
    """Sjekker om `losning` faktisk løser `problem`.

    Grener på om problemet ser ut som en differensialligning (inneholder
    "diff(" eller "y(x)") eller en vanlig ligning/uttrykk, siden de trenger
    ulik SymPy-maskineri (checkodesol vs. numerisk substitusjon).
    """
    try:
        if _er_ode(problem):
            return _valider_ode(problem, losning)
        return _valider_algebraisk(problem, losning)
    except Exception as e:
        return {
            "validert": False,
            "detaljer": f"Automatisk validering feilet med en uventet feil ({e!r}). "
            "Stol ikke på svaret uten å kontrollere det for hånd.",
        }


def _valider_ode(problem: str, losning: str) -> dict:
    if "=" in problem:
        venstre, hoyre = problem.split("=", 1)
        ode_expr = sympy.Eq(_parse(venstre), _parse(hoyre))
    else:
        parset = _parse(problem)
        # Problemstrengen kan enten være et uttrykk som implisitt betyr
        # "... = 0" (f.eks. "y(x).diff(x) + 4*y(x)"), ELLER allerede være
        # en ferdig Eq (f.eks. "Eq(y(x).diff(x), y(x))"). Ikke pakk en
        # allerede ferdig Eq inn i enda en Eq(..., 0) - det gir en meningsløs
        # sammenligning som SymPy forenkler til False.
        ode_expr = parset if isinstance(parset, sympy.Eq) else sympy.Eq(parset, 0)

    hoyre_losning = losning.split("=", 1)[1] if "=" in losning else losning
    try:
        rhs_expr = _parse(hoyre_losning)
    except Exception as e:
        return {
            "validert": False,
            "detaljer": f"Klarte ikke å tolke løsningen '{losning}' som et SymPy-uttrykk ({e!r}).",
        }
    sol_eq = sympy.Eq(_Y(_X), rhs_expr)

    try:
        ok, rest = sympy.checkodesol(ode_expr, sol_eq)
    except Exception:
        ok, rest = None, None

    if ok is True:
        return {
            "validert": True,
            "detaljer": "SymPy checkodesol() bekrefter at løsningen tilfredsstiller "
            f"differensialligningen '{ode_expr}' identisk (rest = 0).",
        }
    if ok is False:
        return {
            "validert": False,
            "detaljer": f"SymPy checkodesol() fant at løsningen IKKE tilfredsstiller "
            f"ligningen symbolsk. Rest etter innsetting: {rest}.",
        }

    # checkodesol klarte ikke å avgjøre det symbolsk (ok is None) - fall
    # tilbake til numerisk sjekk: sett inn løsningen i ligningen, gi
    # eventuelle frie konstanter (C1, C2, ...) en konkret verdi, og evaluer
    # differensen mellom venstre og høyre side i 3 tilfeldige x-punkter.
    frie_konstanter = (rhs_expr.free_symbols - {_X})
    konstant_subs = {c: random.uniform(0.5, 2.0) for c in frie_konstanter}
    return _numerisk_sjekk_i_punkter(
        uttrykk_som_skal_vaere_null=(ode_expr.lhs - ode_expr.rhs).subs(_Y(_X), rhs_expr).doit().subs(konstant_subs),
        variabel=_X,
        beskrivelse=f"differensialligningen '{ode_expr}' med konstanter satt til {konstant_subs}",
    )


def _valider_algebraisk(problem: str, losning: str) -> dict:
    if "=" in problem:
        venstre, hoyre = problem.split("=", 1)
        differanse = _parse(venstre) - _parse(hoyre)
    else:
        differanse = _parse(problem)

    hoyre_losning = losning.split("=", 1)[1] if "=" in losning else losning
    try:
        losnings_verdier = [
            _parse(v) for v in hoyre_losning.replace("[", "").replace("]", "").split(",") if v.strip()
        ]
    except Exception as e:
        return {
            "validert": False,
            "detaljer": f"Klarte ikke å tolke løsningen '{losning}' som (en liste av) tallverdier ({e!r}).",
        }

    if not losnings_verdier:
        return {
            "validert": False,
            "detaljer": "Fant ingen tallverdi i løsningen å validere mot - kan være en "
            "symbolsk/åpen oppgave (f.eks. bevis) som ikke kan sjekkes numerisk.",
        }

    frie = sorted(differanse.free_symbols, key=str)
    if not frie:
        # Ingen fri variabel igjen - problemet er allerede et konkret tall
        # (f.eks. en verifikasjon som "2+2=4"). Sjekk direkte.
        try:
            verdi = complex(differanse.evalf())
        except Exception as e:
            return {"validert": False, "detaljer": f"Kunne ikke evaluere '{differanse}' numerisk: {e!r}."}
        ok = abs(verdi) < _TOLERANSE
        return {"validert": ok, "detaljer": f"'{problem}' evaluerer til {verdi}; {'stemmer' if ok else 'stemmer IKKE'}."}

    variabel = frie[0]
    detaljer = []
    alle_ok = True
    for verdi in losnings_verdier:
        try:
            residual = complex(differanse.subs(variabel, verdi).evalf())
        except Exception as e:
            alle_ok = False
            detaljer.append(f"{variabel}={verdi}: kunne ikke evalueres ({e!r})")
            continue
        ok = abs(residual) < _TOLERANSE
        alle_ok = alle_ok and ok
        detaljer.append(f"{variabel}={verdi}: {'OK' if ok else 'FEIL'} (residual={residual})")

    return {
        "validert": alle_ok,
        "detaljer": "Satte løsningen inn i '" + str(differanse) + " = 0' og evaluerte: " + "; ".join(detaljer),
    }


def _numerisk_sjekk_i_punkter(uttrykk_som_skal_vaere_null, variabel, beskrivelse: str) -> dict:
    """Evaluerer et uttrykk (som skal bli ~0 hvis løsningen er riktig) i 3
    tilfeldige punkter med subs/evalf, jf. kravet i OPPGAVE.md/SYSTEMBESKRIVELSE.md."""
    punkter = [round(random.uniform(0.2, 3.0), 3) for _ in range(3)]
    detaljer = []
    alle_ok = True
    for p in punkter:
        try:
            residual = complex(uttrykk_som_skal_vaere_null.subs(variabel, p).evalf())
        except Exception as e:
            alle_ok = False
            detaljer.append(f"{variabel}={p}: kunne ikke evalueres ({e!r})")
            continue
        ok = abs(residual) < _TOLERANSE
        alle_ok = alle_ok and ok
        detaljer.append(f"{variabel}={p}: {'OK' if ok else 'FEIL'} (residual={residual})")

    return {
        "validert": alle_ok,
        "detaljer": f"Numerisk sjekk av {beskrivelse} i 3 tilfeldige punkter: " + "; ".join(detaljer),
    }
